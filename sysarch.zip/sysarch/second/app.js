/* 
	DANGCALAN, NINA DIANNE
*/

const express = require('express');
const mysql = require('mysql');
const port = 3300;

// Create a database connection to MySQL
const db = mysql.createPool({
    host: "127.0.0.1",
    user: "root",
    password: "",
    database: "studentdb",
    multipleStatements: true,
});

const app = express();

// Middleware to serve static files
app.use(express.static('public')); 
app.use(express.urlencoded({ extended: false })); 
app.use(express.json());

// Route to fetch students data
app.get("/students", (req, res) => {
    let sql = "SELECT * FROM `students`";
    db.query(sql, (err, results, fields) => {
        if (err) {
            console.log(`SQL error: ${err}`);
            return res.status(500).json("SQL Error");
        }
        return res.status(200).json(results);
    });
});

// Route to handle user login validation
app.post("/validateuser", (req, res) => {
    let username = req.body.username;
    let password = req.body.password;

    let sql = "SELECT * FROM users WHERE username = ? AND password = ?";
    db.query(sql, [username, password], (err, results) => {
        if (err) {
            console.log(`SQL error: ${err}`);
            return res.status(500).json("SQL Error");
        }

        // If a user is found with the given credentials
        if (results.length > 0) {
            res.json({ loginSuccess: true, message: "LOGIN ACCEPTED" });
        } else {
            res.json({ loginSuccess: false, message: "LOGIN FAILED" });
        }
    });
});

// Route for the homepage
app.get("/", (req, res) => {
    res.send("hello world");
});

// Start the server and listen on the specified port
const server = app.listen(port, () => {
    console.log(`Listening at port ${port}`);
});
