/* 
	DANGCALAN, NINA DIANNE
*/

const express = require("express");
const port = 3300;
const app = express();

let users = [
	{'username':'alpha', 'password':'hello123'},
	{'username':'bravo', 'password':'hello123'},
	{'username':'charlie', 'password':'hello123'},
	{'username':'delta', 'password':'hello123'},
	{'username':'echo', 'password':'hello123'},
];

app.use(express.static('public'));
app.use(express.urlencoded({'extended':false}));
app.use(express.json());

app.get("/users", (req, res)=>{
	res.send(users);
});

app.post("/validateuser", (req, res)=>{
	let username = req.body.username;
	let password = req.body.password;
	const user = users.find(user => user.username == username && user.password == password);

    if (user) {
        res.send("LOGIN ACCEPTED");
    } else {
        res.send("LOGIN FAILED");
    }
});

app.get("/", (req, res)=>{
	res.send("hello sysarch!!!");
});

const server = app.listen(port,()=>{
	console.log(`listening at port ${port}`);
});